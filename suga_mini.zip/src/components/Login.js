import React from 'react';

function Login(){
  return(
    <div>
      Hiiii Hello
    </div>
  );
}
export default Login;