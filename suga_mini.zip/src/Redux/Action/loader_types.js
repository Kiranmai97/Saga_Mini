const LoaderTypes = {
    LOADER_START: "LOADER_START",
    LOADER_STOP: "LOADER_STOP",
  };
  
  export { LoaderTypes };
  